//Programmer: Albert Putra Purnama
//Student ID: 1559220

#ifndef Rider_h
#define Rider_h

#include<iostream>
#include<vector>
#include<string>
#include<set>
using namespace std;

#include<cstring>

struct Rider
{
  int to;
  int from;
  Rider(int, int);
  Rider& operator=(const Rider&);
};

#endif
